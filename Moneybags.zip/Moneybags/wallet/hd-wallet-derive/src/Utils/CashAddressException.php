<?php

namespace App\Utils;

class CashAddressException extends \Exception
{

}
