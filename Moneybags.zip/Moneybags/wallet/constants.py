# set constants
BTC = 'btc'
ETH = 'eth'
BTCTEST = 'btc-test'
